#include <iostream>
#include <math.h>

using namespace std;

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) {
	
	int numeros[4][4], i, j;
	
	//capturar numeros en la columna
	
	for( j=0;j<4;j++)	
	{
		cout<<"digite un numero para la posicion "<<j<<" ";
			cin>>numeros[j][i];
		
		
		
	}
	
	// mostrar numeros de la columna
	
	
	for(j=0;j<4;j++)
	{
		cout<<numeros[j][i];
		
		cout<<endl;
	}
	
	
	for(j=0;j<4;j++)
	{
		numeros[j][i]=pow(j,2);
	}
	
	cout<<endl;
	
	for(j=0;j<4;j++)
	{
		cout<<numeros[j][i];
		
		cout<<endl;
	}
	
	
	
		
	
	
	return 0;
}
