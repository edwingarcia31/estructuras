#include <iostream>

using namespace std;



/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) {
	
	int i, factorial=0, numero=0;
	
	cout<<"ingrese numero a solucionar"<<endl;
	cin>>numero;
	factorial=numero;
	
	system("cls");
	
	for(i=numero-1;i>=1;i--){
		
		factorial=factorial*i;
		
			
	}
	
		cout<<"el factorial del numero "<<numero<<" es "<<factorial<<endl;
	
	return 0;
}
