#include <iostream>

using namespace std;

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) 
{
	int n, x=0, y=1, z=1;
	
	cout<<"digite el numero a resolver ";
	cin>>n;
	
	cout<<"1 ";
	
	for(int i=1;i<n;i++){
		z=x+y;
		
		cout<<z<<" ";
		x=y;
		y=z;
	}
	
	cout<<endl;
	system("pause");
	return 0;
}
