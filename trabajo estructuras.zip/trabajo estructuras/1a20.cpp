#include <iostream>

using namespace std;

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) {
	
	int numero, resultado;
	
	cout<<"ingrese numero a multiplicar";
	cin>>numero;
	
	for(int i=0;i<=20; i++){
		
		resultado=numero*i;
		
		cout<<numero<<"*"<<i<<"="<<resultado<<endl;
	}
	return 0;
}
