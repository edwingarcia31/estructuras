#include <iostream>

using namespace std;
/* run this program using the console pauser or add your own getch, system("pause") or input loop */





int main(int argc, char** argv) {
	
float num[4]={32.583, 11.239, 45.781, 22.237};
	
	for(int i=0;i<4;i++)
{
	cout<<num[i]<<endl;
}
	return 0;
}
